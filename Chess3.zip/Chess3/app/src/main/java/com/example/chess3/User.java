package com.example.chess3;

public class User {
    public String email;
    public String password;
    public String status;
    public String lastMessage;

    public User() {
        String email ="";
        String password ="";
        String status ="";
        String lastMessage="";
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String email, String password) {
        this.password = password;
        this.email = email;
        this.status="offline";
        this.lastMessage="";
    }
    
}
