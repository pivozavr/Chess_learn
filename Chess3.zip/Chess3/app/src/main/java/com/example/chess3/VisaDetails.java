package com.example.chess3;

public class VisaDetails extends  User {
    private String visaNumber;
    private String expireDate;
    private String cvv;

    public VisaDetails(String email, String password, String visaNumber, String expireDate, String cvv) {
        super(email, password);
        this.visaNumber = visaNumber;
        this.expireDate = expireDate;
        this.cvv = cvv;
    }
    public VisaDetails(String visaNumber, String expireDate, String cvv) {
            super();
            this.visaNumber = visaNumber;
            this.expireDate = expireDate;
            this.cvv = cvv;

    }
}
